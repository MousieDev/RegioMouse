mkdir Shared
passwd
tce-load -wi openssh
tce-load -wi samba3
tce-load -wi vim
tce-load -wi htop