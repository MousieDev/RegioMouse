sudo cp /usr/local/etc/ssh/sshd_config.orig /usr/local/etc/ssh/sshd_config
sudo cp /usr/local/etc/ssh/ssh_config.orig /usr/local/etc/ssh/ssh_config
sudo /usr/local/etc/init.d/openssh start
sudo cp smb.conf /usr/local/etc/samba/smb.conf
sudo /usr/local/etc/init.d/samba start
sudo smbpasswd -a tc
read -p "Device id (example /dev/sdc1): " devid
sudo mount -o uid=1001,gid=50,rw $devid /home/tc/Shared
sudo /usr/local/etc/init.d/samba restart