sudo chmod -R 777 /home/tc/Share
sudo cp /usr/local/etc/ssh/sshd_config.orig /usr/local/etc/ssh/sshd_config
sudo cp /usr/local/etc/ssh/ssh_config.orig /usr/local/etc/ssh/ssh_config
sudo /usr/local/etc/init.d/openssh start
sudo cp smb.conf /usr/local/etc/samba/smb.conf
sudo /usr/local/etc/init.d/samba start
sudo smbpasswd -a tc
sudo /usr/local/etc/init.d/samba restart
passwd
echo Remember to mount shared drive to /home/tc/Shared!